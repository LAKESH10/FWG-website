import re
R='/home/claude/repo/fwg-website/'
b=open('/home/claude/final/fwg-site.html').read()
css=b[b.index('<style>')+7:b.index('</style>')].lstrip('\n').replace('url(img/','url(../img/')
_se=b.index('</style>')+8
body=b[_se:b.index('<script>',_se)].strip('\n')
body=body.replace('src="img/','src="assets/img/')
names=sorted(set(re.findall(r'style="--ph:url\(img/([A-Za-z0-9_.-]+)\)"',body)))
body=re.sub(r'style="--ph:url\(img/([A-Za-z0-9_.-]+)\.[a-z]+\)"',r'data-ph="\1"',body)
assert 'url(img/' not in body
css+='\n/* Section photos (defined here so paths resolve from this file) */\n'+''.join('[data-ph="%s"]{--ph:url(../img/%s)}\n'%(n.rsplit(".",1)[0],n) for n in names)
open(R+'assets/css/styles.css','w').write('/* Base reset (standalone build) */\nhtml{-webkit-text-size-adjust:100%}\nbody{margin:0}\n'+css)
idx=open(R+'index.html').read()
open(R+'index.html','w').write(idx[:idx.index('<body>')+7]+body+'\n\n'+idx[idx.index('<script src="assets/vendor'):])
print('ok',names)

# animated 3D vignettes + motion as separate files
import shutil
open(R+'assets/js/fx3d.js','w').write(open('/home/claude/fx/fx3d.js').read()+'\n'+open('/home/claude/fx/motion.js').read())
shutil.copy('/home/claude/icons/RoomEnvironment.js',R+'assets/vendor/RoomEnvironment.js')
idx=open(R+'index.html').read()
tag='<script src="assets/vendor/RoomEnvironment.js" defer></script>\n<script src="assets/js/fx3d.js" defer></script>\n'
if 'fx3d.js' not in idx:
    idx=idx.replace('<script src="assets/js/main.js" defer></script>\n','<script src="assets/js/main.js" defer></script>\n'+tag)
open(R+'index.html','w').write(idx)
print('fx files written')

# ---- SEO: head meta block, clean-URL router, per-route static pages, sitemap, vercel config ----
import re,os,json,sys
sys.path.insert(0,'/home/claude/fx')
from meta import META,block
shutil.copy('/home/claude/fx/paths.js',R+'assets/js/paths.js')
idx=open(R+'index.html').read()
head,rest=idx.split('<body>',1)
head=re.sub(r'<!--meta-->.*?<!--/meta-->\n?','',head,flags=re.S)
head=re.sub(r'<meta name="description" content="[^"]*">\n?','',head)
head=re.sub(r'<link rel="canonical"[^>]*>\n?','',head)
head=head.replace('</head>','  <link rel="canonical" href="https://fwg.global/">\n  '+block+'\n</head>')
idx=head+'<body>'+rest
if 'assets/js/paths.js' not in idx:
    idx=idx.replace('<script src="assets/vendor/three.min.js" defer></script>','<script src="assets/js/paths.js" defer></script>\n<script src="assets/vendor/three.min.js" defer></script>')
open(R+'index.html','w').write(idx)
# per-route copies
for pg,(t,d,path) in META.items():
    if path=='/':continue
    h=idx
    h=re.sub(r'<title>.*?</title>','<title>%s</title>'%t,h,count=1,flags=re.S)
    h=re.sub(r'(<!--meta-->\n<meta name="description" content=")[^"]*(">)',lambda m:m.group(1)+d.replace('"','&quot;')+m.group(2),h,count=1)
    h=re.sub(r'(<meta property="og:title" content=")[^"]*(">)',lambda m:m.group(1)+t+m.group(2),h,count=1)
    h=re.sub(r'(<meta property="og:description" content=")[^"]*(">)',lambda m:m.group(1)+d.replace('"','&quot;')+m.group(2),h,count=1)
    h=h.replace('<link rel="canonical" href="https://fwg.global/">','<link rel="canonical" href="https://fwg.global%s">'%path)
    h=re.sub(r'(src|href)="assets/',r'\1="/assets/',h)
    h=h.replace('content="assets/','content="/assets/')
    os.makedirs(R+path.strip('/'),exist_ok=True)
    open(R+path.strip('/')+'/index.html','w').write(h)
sm='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join('  <url><loc>https://fwg.global%s</loc></url>\n'%v[2] for k,v in META.items() if k!='review')+'</urlset>\n'
open(R+'sitemap.xml','w').write(sm)
open(R+'vercel.json','w').write(json.dumps({"cleanUrls":True,"trailingSlash":False},indent=2)+'\n')
print('seo build ok')

# ---- regenerate main.js from the preview's inline scripts (router, theme, scenes, parallax) ----
_se=b.index('</style>')+8;_fx=b.index('<!--fx3d-->')
chunks=re.findall(r'<script>(.*?)</script>',b[_se:_fx],flags=re.S)
hdr='/* FWG Group website\n * 1. Router, menus, review notes, forms\n * 2. Theme, fades, home interactions and 3D scenes (three.js r128)\n * 3. Background parallax\n */\n'
open(R+'assets/js/main.js','w').write(hdr+'\n'.join(c.strip('\n') for c in chunks)+'\n')
idx=open(R+'index.html').read().replace('family=Manrope:wght@500;600;700;800&','family=Manrope:wght@500;600;700&')
open(R+'index.html','w').write(idx)
for root,ds,fs in os.walk(R):
    if '.git' in root or 'assets' in root:continue
    for f in fs:
        if f=='index.html' and root.rstrip('/')!=R.rstrip('/'):
            q=os.path.join(root,f);t=open(q).read().replace('family=Manrope:wght@500;600;700;800&','family=Manrope:wght@500;600;700&');open(q,'w').write(t)
print('main.js regenerated from',len(chunks),'inline scripts')
