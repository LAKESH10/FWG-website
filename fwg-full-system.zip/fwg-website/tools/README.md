# Source and build tools

Not deployed (see `.vercelignore`). Kept so the site can be rebuilt or edited.

- `fwg-site.html` – the master single-file version of the whole site (all pages, styles and scripts). Edit this first.
- `build_repo.py` – splits the master file into the deployable site (index.html, assets/css, assets/js, one folder per page, sitemap.xml). Paths inside the script point at the original build machine; adjust `R` and the input path before running.
- `fx/fx3d.js` – the animated 3D scenes (service cards, steps, FWG headquarters building).
- `fx/motion.js` – scroll reveals, counters, enquiry form, floating hotline.
- `fx/paths.js` – clean URLs (fwg.global/malaysia/security) on top of the in-page router.
- `fx/meta.py` – page titles, descriptions and structured data per page.
- `fx/certs.json` – captions for the certificate wall.
- `icons/render2.html` – renders the static 3D icon images (shield, pin, camera, building, target).
