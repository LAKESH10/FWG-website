import json
META={
 'home':('FWG Group | Securing people. Protecting business.','FWG Group: your end-to-end urban security partner since 1995. Manned guarding, escort, electronic security, safety and risk across Malaysia and India.','/'),
 'about':('About FWG | Security since 1995','From one security licence in Seremban in 1995 to a regional group: FWG\'s mission, vision, values, history and board of directors.','/about'),
 'accreditations':('Accreditations and awards | FWG Group','ISO 9001:2015, TAPA, UKAS, ESQR, ISCPP, CCTP and more. The certifications, memberships and awards behind FWG\'s security services.','/accreditations'),
 'quote':('Request a security quote | FWG Group','Tell FWG what you need protected. Your request goes to the security team in Malaysia, India or Singapore.','/quote'),
 'malaysia':('FWG in Malaysia | Security, trustee and property','Headquartered in Seremban since 1995, FWG protects sites across Peninsular and East Malaysia and runs trust and property businesses.','/malaysia'),
 'security':('Security services in Malaysia | Guarding, escort, canine | FWG','Manned guarding, VIP and cash-in-transit escort, canine unit and safety and risk management across Malaysia. ISO 9001:2015 guarding.','/malaysia/security'),
 'electronic':('Electronic security in Malaysia | CCTV, iVMS, GPS | FWG','CCTV and video analytics, cloud visitor management (iVMS), alarms and access control, and GPS tracking from FWG\'s command centre.','/malaysia/electronic-security'),
 'branches':('FWG branches in Malaysia | Seremban HQ and coverage','FWG head office in Seremban, a Selangor regional office and operations in 13 Malaysian states and cities, from Penang to Sabah and Sarawak.','/malaysia/branches'),
 'trustee':('FWG Trustee Berhad | Wills, trusts and estates','FWG Trustee Berhad helps families and business owners plan wills and trusts, administer estates and secure their legacy.','/malaysia/trustee'),
 'property':('FWG Property | Homes in Seremban and Semenyih','Single-storey homes in Bandar Seremban Selatan from RM350,000, and upcoming homes in Rinching, Semenyih.','/malaysia/property'),
 'india':('FWG India | Security and facility services, Chennai','Freightwatch G Security Services (India): manned security, security technology, training, facility management and skilled services across India.','/india'),
 'singapore':('FWG in Singapore | Coming soon','FWG is preparing to serve clients in Singapore. Register your interest and we will be in touch as services launch.','/singapore'),
 'ventures':('FWG Ventures','Growing entrepreneurs into global icons. Building tomorrow\'s leaders through sound investments.','/ventures'),
 'careers':('Careers at FWG | Security jobs in Malaysia and India','Build a career in security with FWG. Officers, supervisors, escort teams, technicians and office roles in Malaysia and India.','/careers'),
 'news':('News | FWG Group','Awards, projects, announcements and insights from across the FWG Group.','/news'),
 'faq':('FAQ | FWG Group','Answers to common questions about FWG security services, electronic security, quotes, offices in Malaysia and India, and careers.','/faq'),
 'contact':('Contact FWG | Hotline 1300 22 0000','Call FWG Malaysia on 1300 22 0000 or FWG India on +91 44 4005 0684, or send an enquiry to the right country team.','/contact'),
 'privacy':('Privacy notice | FWG Group','How FWG collects and uses personal data submitted through this website, and your rights in Malaysia, India and Singapore.','/privacy'),
 'review':('Review list | FWG Group','Items for FWG to confirm before launch.','/review'),
}
meta_js='window.FWG_META='+json.dumps({k:{'t':v[0],'d':v[1],'p':v[2]} for k,v in META.items()},ensure_ascii=False)+';'
org={"@context":"https://schema.org","@graph":[
 {"@type":"Organization","@id":"https://fwg.global/#org","name":"FWG Group","url":"https://fwg.global/","logo":"https://fwg.global/assets/img/fwg-logo.png","slogan":"Securing people. Protecting business.","foundingDate":"1995",
  "sameAs":["https://www.facebook.com/FWG.GlobalSS/","https://www.instagram.com/fwg.global/","https://www.linkedin.com/company/freightwatch-g-patomotoh-security-services-sdn-bhd","https://twitter.com/FWG_Global"]},
 {"@type":"LocalBusiness","name":"Freightwatch G Patomotoh Security Services Sdn Bhd","parentOrganization":{"@id":"https://fwg.global/#org"},"telephone":"+60 6-677 2000","email":"info@fwg.my",
  "address":{"@type":"PostalAddress","streetAddress":"No 23 & 24, 1st Floor, Taman Bukit Emas, Jalan Tampin","addressLocality":"Seremban","postalCode":"70450","addressRegion":"Negeri Sembilan","addressCountry":"MY"}},
 {"@type":"LocalBusiness","name":"Freightwatch G Security Services (India) Pvt. Ltd.","parentOrganization":{"@id":"https://fwg.global/#org"},"telephone":"+91 44 4005 0684","email":"info@fwgindia.com",
  "address":{"@type":"PostalAddress","streetAddress":"Precision Plaza, 1st Floor, No. 397 (Old No. 281), Anna Salai, Teynampet","addressLocality":"Chennai","postalCode":"600018","addressRegion":"Tamil Nadu","addressCountry":"IN"},
  "openingHours":"Mo-Sa 09:00-18:00"}]}
ld='<script type="application/ld+json">'+json.dumps(org,ensure_ascii=False)+'</script>'
block='<!--meta-->\n<meta name="description" content="%s">\n'%META['home'][1]+ld+'\n<script>'+meta_js+'</script>\n<!--/meta-->'
if __name__=='__main__':
    p='/home/claude/final/fwg-site.html';s=open(p).read()
    if '<!--meta-->' in s:
        a=s.index('<!--meta-->');b=s.index('<!--/meta-->')+len('<!--/meta-->');s=s[:a]+block+s[b:]
    else:
        # remove old single description, insert block after <title>
        import re
        s=re.sub(r'<meta name="description" content="[^"]*">\n?','',s,count=1)
        i=s.index('</title>')+8;s=s[:i]+'\n'+block+s[i:]
    # router hook
    a="var h=(location.hash||'#home').slice(1),target=h,anchor=null;"
    if a in s: s=s.replace(a,"var h=(window.FWG_ROUTE?window.FWG_ROUTE():(location.hash||'#home').slice(1)),target=h,anchor=null;")
    a="document.title=target==='home'?'FWG Group':(t?t.textContent+' · FWG Group':'FWG Group');"
    if a in s: s=s.replace(a,"""var M=window.FWG_META&&FWG_META[target];document.title=M?M.t:(t?t.textContent+' · FWG Group':'FWG Group');
    if(M){var md=document.querySelector('meta[name=description]');if(md)md.setAttribute('content',M.d);var og=document.querySelector('meta[property="og:title"]');if(og)og.setAttribute('content',M.t);var od=document.querySelector('meta[property="og:description"]');if(od)od.setAttribute('content',M.d);var cl=document.querySelector('link[rel=canonical]');if(cl)cl.setAttribute('href','https://fwg.global'+M.p)}
    window.dispatchEvent(new CustomEvent('fwg:route',{detail:target}));""")
    open(p,'w').write(s);print('meta injected')
