p='/home/claude/final/fwg-site.html';s=open(p).read()
a=s.index('<!--fx3d-->');b=s.index('<!--/fx3d-->')
room=open('/home/claude/icons/RoomEnvironment.js').read();fx=open('/home/claude/fx/fx3d.js').read()+'\n'+open('/home/claude/fx/motion.js').read()
s=s[:a]+'<!--fx3d-->\n<script>\nif(window.THREE){\n'+room+'\n}\n</script>\n<script>\n'+fx+'\n</script>\n'+s[b:]
open(p,'w').write(s)
head='<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;font:14px system-ui}[hidden]{display:none!important}</style>\n'
open('/home/claude/final/preview.html','w').write(head+s+'\n</body></html>')
print('injected')
