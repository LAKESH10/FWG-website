/* FWG motion: staggered reveals, number count-up. Respects reduced motion. */
(function(){
  var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  var groups=[].slice.call(document.querySelectorAll('.stagger'));
  groups.forEach(function(g){[].slice.call(g.children).forEach(function(c,i){c.style.setProperty('--i',i)})});
  var nums=[].slice.call(document.querySelectorAll('[data-count]'));
  function count(el){var to=+el.getAttribute('data-count'),from=+(el.getAttribute('data-from')||0),t0=null,D=1400;
    function f(now){if(!t0)t0=now;var p=Math.min(1,(now-t0)/D),e=1-Math.pow(1-p,3);var v=Math.round(from+(to-from)*e);el.textContent=(to>=1000&&!el.hasAttribute('data-plain'))?v.toLocaleString('en-US'):v;if(p<1)requestAnimationFrame(f)}
    el.textContent=from;requestAnimationFrame(f)}
  if(reduce||!('IntersectionObserver' in window)){groups.forEach(function(g){g.classList.add('in')});return}
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(!e.isIntersecting)return;var t=e.target;io.unobserve(t);
    if(t.hasAttribute('data-count'))count(t);else t.classList.add('in')})},{threshold:.18});
  groups.concat(nums).forEach(function(x){io.observe(x)});
})();
/* general enquiry form (preview: does not send) */
(function(){var f=document.getElementById('enquiry-form');if(!f)return;var d=document.getElementById('enquiry-done');
  f.addEventListener('submit',function(e){e.preventDefault();if(!f.checkValidity()){f.reportValidity();return}
    d.textContent='Thank you. In the live site your message would now go to the FWG team. This preview does not send anything.';d.classList.add('show')})})();
/* country-aware contact widgets: hotline, WhatsApp, quote country preset */
(function(){
  /* WhatsApp numbers per country, digits only with country code (e.g. '60123456789'). Leave empty to hide the button. */
  var WA={MY:'',IN:'',SG:''};
  var IN_PAGES=['india'],SG_PAGES=['singapore'];
  var fl=document.getElementById('float'),wa=document.getElementById('wa');
  function country(p){return IN_PAGES.indexOf(p)>=0?'IN':SG_PAGES.indexOf(p)>=0?'SG':'MY'}
  function apply(p){var c=country(p);
    if(fl){var b=fl.querySelector('b');if(c==='IN'){b.textContent='+91 44 4005 0684';fl.setAttribute('href','#india-contact');fl.setAttribute('aria-label','Talk to FWG India, +91 44 4005 0684')}
      else{b.textContent='1300 22 0000';fl.setAttribute('href','#quote');fl.setAttribute('aria-label','Talk to FWG, hotline 1300 22 0000')}}
    if(wa){var n=WA[c]||WA.MY;if(n){wa.hidden=false;wa.href='https://wa.me/'+n}else wa.hidden=true}}
  window.addEventListener('fwg:route',function(e){apply(e.detail)});
  var cur=document.querySelector('section.page:not([hidden])');apply(cur?cur.getAttribute('data-page'):'home');
  document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('[data-country]');if(!a)return;var c=a.getAttribute('data-country');
    setTimeout(function(){var sel=document.getElementById('q-country');if(sel)sel.value=c},60)});
})();
